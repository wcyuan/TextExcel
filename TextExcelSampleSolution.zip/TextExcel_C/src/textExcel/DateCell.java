package textExcel;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateCell implements Cell, Comparable<DateCell> 
{
    String dateString;

    public DateCell(String input)
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        Date date = dateFormat.parse(input, new ParsePosition(0));
        dateString = dateFormat.format(date);
    }

    @Override
    public String abbreviatedCellText() 
    {
        return dateString;
    }

    @Override
    public String fullCellText() 
    {
        return dateString;
    }

    public int compareTo(DateCell that)
    {
        int ret;

        String[] date1Components = this.fullCellText().split("/"); 
        String[] date2Components = that.fullCellText().split("/");

        // Compare years first
        ret = date1Components[2].compareTo(date2Components[2]);
        if (ret != 0)
            return ret;

        // Compare months next
        ret = date1Components[0].compareTo(date2Components[0]);
        if (ret != 0)
            return ret;

        // Finally, compare dates
        return date1Components[1].compareTo(date2Components[1]);
    }	

}
