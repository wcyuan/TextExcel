package textExcel;

public abstract class RealCell implements Cell, Comparable<RealCell>
{
	private String input;
	
	public RealCell(String input)
	{
		this.input = input;
	}
	
	public abstract double getDoubleValue();
	
	@Override
	public String abbreviatedCellText() 
	{
		String valueString = "" + getDoubleValue();
		
		return Spreadsheet.padOrTruncate(valueString);
	}

	@Override
	public String fullCellText() 
	{
		return input;
	}
	
	public int compareTo(RealCell that)
    {
        // TODO: If these are formulas, the act of sticking them into the spreadsheet
        // could unsort them or cause circular references.
        // This can cause infinite recursion once they're put back into the sheet and re-evaluated.
        if (this.getDoubleValue() < that.getDoubleValue())
            return -1;
        
        if (this.getDoubleValue() > that.getDoubleValue())
            return 1;
        
        return 0;
    }

	
}
